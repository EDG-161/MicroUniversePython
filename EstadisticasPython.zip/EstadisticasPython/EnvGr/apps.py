from django.apps import AppConfig


class EnvgrConfig(AppConfig):
    name = 'EnvGr'
